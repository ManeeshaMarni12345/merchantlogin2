package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;



import service.merchantService;

public class merchantcontroller {
	@Autowired
	merchantService ser;
	@Autowired
	
	  @RequestMapping(value = "/login/{username}/{password}")
  	public int  lo(@PathVariable String username,@PathVariable String password) {
  		return ser.loginByUsername(username, password);
  	}

}
