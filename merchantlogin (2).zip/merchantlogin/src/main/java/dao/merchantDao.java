package dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import bean.merchant;

public interface merchantDao extends JpaRepository<merchant, Integer> {
    @Query("from Customer where uName=:u")
    merchant getMerchantByUsername(@Param("u") String uName);
}


