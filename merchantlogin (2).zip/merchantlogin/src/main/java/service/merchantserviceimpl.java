package service;

import org.springframework.beans.factory.annotation.Autowired;



import bean.merchant;
import dao.merchantDao;

public class merchantserviceimpl implements merchantService{
	@Autowired
	  merchantDao dao;
	@Override
	public int loginByUsername(String uName, String pwd) {
		
		merchant merchant=dao.getMerchantByUsername(uName);
		 if(merchant.getPwd().equals(pwd))
		        return merchant.getMerchant_id();
		return 0;
		// TODO Auto-generated method stub
	
	}
	

}
