package service;

public interface merchantService {
	 public int loginByUsername(String uName, String pwd);

}
